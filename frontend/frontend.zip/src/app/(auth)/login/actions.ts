"use server";

import axios from "axios";

export async function loginAction(formData: FormData) {
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;

  try {
    const res = await axios.post("http://localhost:8000/api/v1/auth/login", {
      email,
      password,
    });

    return {
      token: res.data.access_token,
      user: res.data.user,
    };
  } catch (error: any) {
    return {
      error: error.response?.data?.detail || "Invalid email or password",
    };
  }
}
